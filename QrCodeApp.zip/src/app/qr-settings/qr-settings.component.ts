import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qr-settings',
  templateUrl: './qr-settings.component.html',
  styleUrls: ['./qr-settings.component.scss']
})
export class QrSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
